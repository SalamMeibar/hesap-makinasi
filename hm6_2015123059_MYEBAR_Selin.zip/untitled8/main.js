
const keys = document.querySelector(".calculator");
const display = document.querySelector(".calculator__screen");

const calculate = (n1, operator, n2) => {
    if (operator === 'add') {
        return parseFloat(n1) + parseFloat(n2);
    } else if (operator === 'subtract') {
        return parseFloat(n1) - parseFloat(n2);
    } else if (operator === 'divide') {
        return parseFloat(n1) / parseFloat(n2);
    } else if (operator === 'multiply') {
        return parseFloat(n1) * parseFloat(n2);
    }
    else if (operator === 'c') {
        return clearInterval()
    }
}

keys.addEventListener("click", e => {
    if (e.target.matches("button")) {
        const key = e.target;
        const action = key.dataset.action;
        const keyContent = key.textContent;
        const displayedNum = display.textContent;
        const previousKeyType = keys.dataset.previousKeyType;

        Array.from(key.parentNode.children)
            .forEach(k => k.classList.remove('is-depressed'));

        if (!action) {
            if (displayedNum === "0" || previousKeyType === 'operator') {
                display.textContent = keyContent;
            } else {
                display.textContent = displayedNum + keyContent;
            }
            keys.dataset.previousKeyType = 'number';
        }

        if (
            action === "divide" ||
            action === "multiply" ||
            action === "subtract" ||
            action === "add"||
            action === "clear"

        ) {
            console.log("Operator " + action);

            keys.dataset.firstValue = displayedNum;
            keys.dataset.operator = action;

            key.classList.add('is-depressed');
            keys.dataset.previousKeyType = 'operator';

        }

        if (action === "decimal") {
            if(!displayedNum.includes('.')) {
                display.textContent = displayedNum + '.';
            }
        }

        if (action === "c") {
       //     console.log("Clear key");
            console.clear()
        }

        if (action === "calculate") {
            const firstValue = keys.dataset.firstValue;
            const operator = keys.dataset.operator;
            const secondValue = displayedNum;

            display.textContent = calculate(firstValue, operator, secondValue);

        }
    }
});